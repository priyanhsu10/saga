package pro.com.stocks_ms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StocksMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
