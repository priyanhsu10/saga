package pro.com.stocks_ms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StocksMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(StocksMsApplication.class, args);
	}

}
